<script setup lang="ts">
import { computed, onUnmounted, ref, watch } from 'vue';
import { Check, Copy, Download, Layers, RotateCcw, Trash2, X } from 'lucide-vue-next';
import { useI18n } from 'vue-i18n';
import type { BatchItem } from '../type';

const { t } = useI18n();

const props = defineProps<{
  items: BatchItem[];
  selectedIds: number[];
  activeId: number | null;
  copiedId: number | null;
  batchCopied: boolean;
}>();

const isSelectable = (item: BatchItem) => item.status === 'done' || item.status === 'error';
const selectableIds = computed(() => props.items.filter(isSelectable).map((item) => item.id));
const hasBatchDownload = computed(() =>
  props.items.some(
    (item) => props.selectedIds.includes(item.id) && item.status === 'done' && !!item.resultUrl,
  ),
);
const hasBatchReprocess = computed(() =>
  props.items.some(
    (item) =>
      props.selectedIds.includes(item.id) && (item.status === 'done' || item.status === 'error'),
  ),
);

const now = ref(Date.now());
const hasRunningItem = computed(() => props.items.some((item) => item.status === 'processing'));
let ticker: ReturnType<typeof setInterval> | null = null;

watch(
  hasRunningItem,
  (running) => {
    if (running && !ticker) {
      now.value = Date.now();
      ticker = setInterval(() => {
        now.value = Date.now();
      }, 1000);
    } else if (!running && ticker) {
      clearInterval(ticker);
      ticker = null;
    }
  },
  { immediate: true },
);

onUnmounted(() => {
  if (ticker) clearInterval(ticker);
});

function itemDuration(item: BatchItem): number | null {
  if (item.status === 'processing' && item.startedAt != null) {
    return now.value - item.startedAt;
  }
  return item.durationMs;
}

function formatDuration(ms: number | null): string {
  if (ms == null) return '';
  const totalSeconds = Math.max(0, ms) / 1000;
  if (totalSeconds < 60) return `${Math.floor(totalSeconds)}s`;
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = Math.floor(totalSeconds % 60);
  return `${minutes}:${String(seconds).padStart(2, '0')}`;
}

const emit = defineEmits<{
  (e: 'toggle', id: number): void;
  (e: 'toggle-range', id: number): void;
  (e: 'select-all'): void;
  (e: 'preview', item: BatchItem): void;
  (e: 'download', item: BatchItem): void;
  (e: 'copy', item: BatchItem): void;
  (e: 'batch', action: 'download' | 'copy' | 'reprocess'): void;
  (e: 'cancel-item', id: number): void;
  (e: 'remove', id: number): void;
}>();

function onCheckClick(event: MouseEvent, item: BatchItem) {
  if (!isSelectable(item)) return;
  if (event.shiftKey) {
    emit('toggle-range', item.id);
    return;
  }
  emit('toggle', item.id);
}

function onRowClick(event: MouseEvent, item: BatchItem) {
  if (event.shiftKey && isSelectable(item)) {
    emit('toggle-range', item.id);
    return;
  }
  emit('preview', item);
}
</script>

<template>
  <section class="queue-panel">
    <div class="queue-header">
      <div class="queue-header-left">
        <label class="queue-select-all">
          <input
            type="checkbox"
            :checked="
              selectableIds.length > 0 && selectableIds.every((id) => selectedIds.includes(id))
            "
            :disabled="selectableIds.length === 0"
            @change="emit('select-all')"
          />
          <span class="queue-title">{{ t('queue.title') }}</span>
        </label>
        <span v-if="selectedIds.length > 0" class="queue-selected">
          {{ t('queue.selected', { count: selectedIds.length }) }}
        </span>
      </div>
      <div v-if="selectedIds.length > 0" class="queue-batch">
        <button
          class="batch-btn"
          :title="t('queue.download')"
          :disabled="!hasBatchDownload"
          @click="emit('batch', 'download')"
        >
          <Download :size="14" />
          <span>{{ t('queue.download') }}</span>
        </button>
        <button
          class="batch-btn"
          :class="{ copied: batchCopied }"
          :title="t('queue.copy')"
          :disabled="!hasBatchDownload"
          @click="emit('batch', 'copy')"
        >
          <Check v-if="batchCopied" :size="14" />
          <Copy v-else :size="14" />
          <span>{{ t('queue.copy') }}</span>
        </button>
        <button
          class="batch-btn"
          :title="t('queue.reprocess')"
          :disabled="!hasBatchReprocess"
          @click="emit('batch', 'reprocess')"
        >
          <RotateCcw :size="14" />
          <span>{{ t('queue.reprocess') }}</span>
        </button>
      </div>
    </div>

    <div v-if="items.length === 0" class="queue-empty">
      <Layers :size="32" :stroke-width="1.5" />
      <p>{{ t('queue.empty') }}</p>
    </div>

    <div v-else class="queue-list" role="list">
      <div
        v-for="item in items"
        :key="item.id"
        class="queue-item"
        :class="{
          done: item.status === 'done',
          processing: item.status === 'processing',
          pending: item.status === 'pending',
          error: item.status === 'error',
          active: activeId === item.id,
        }"
        role="listitem"
        :title="item.status === 'done' ? t('processing.clickToCompare') : item.name"
        @click="onRowClick($event, item)"
      >
        <span class="queue-check-box" @click.stop="onCheckClick($event, item)">
          <input
            type="checkbox"
            class="queue-check"
            :checked="selectedIds.includes(item.id)"
            :disabled="!isSelectable(item)"
          />
        </span>
        <img
          class="queue-thumb"
          :src="item.resultUrl ?? item.originalUrl"
          :alt="item.name"
          role="button"
          tabindex="0"
          @keydown.enter.prevent="emit('preview', item)"
        />
        <div class="queue-info">
          <span class="queue-name" :title="item.name">{{ item.name }}</span>
          <span
            class="queue-meta"
            :title="item.status === 'error' ? (item.error ?? '') : undefined"
          >
            <template v-if="item.status === 'pending'">{{ t('processing.pending') }}</template>
            <template v-else-if="item.status === 'processing'">
              {{ t('processing.itemProcessing') }} · {{ formatDuration(itemDuration(item)) }}
            </template>
            <template v-else-if="item.status === 'error'">
              {{ item.error || t('processing.failed') }}
            </template>
            <template v-else-if="item.resultSize">
              {{ item.resultSize.width }}×{{ item.resultSize.height }}
              <template v-if="item.durationMs != null">
                · {{ formatDuration(item.durationMs) }}
              </template>
            </template>
          </span>
        </div>
        <div
          v-if="item.status === 'processing'"
          class="queue-ring"
          :style="{ '--p': item.progress }"
        >
          <span class="queue-ring-label">{{ item.progress }}%</span>
        </div>
        <Check v-else-if="item.status === 'done'" class="queue-done-icon" :size="16" />
        <span
          v-else-if="item.status === 'error'"
          class="queue-error-dot"
          :title="item.error ?? ''"
        />
        <div v-if="item.status === 'done'" class="queue-actions">
          <button
            class="queue-action"
            :title="t('processing.download')"
            @click.stop="emit('download', item)"
          >
            <Download :size="14" />
          </button>
          <button
            class="queue-action"
            :class="{ copied: copiedId === item.id }"
            :title="copiedId === item.id ? t('processing.copied') : t('processing.copy')"
            @click.stop="emit('copy', item)"
          >
            <Check v-if="copiedId === item.id" :size="14" />
            <Copy v-else :size="14" />
          </button>
        </div>
        <button
          v-if="item.status === 'processing'"
          class="queue-cancel"
          :title="t('processing.cancel')"
          @click.stop="emit('cancel-item', item.id)"
        >
          <X :size="14" />
        </button>
        <button
          v-else
          class="queue-remove"
          :title="t('queue.remove')"
          @click.stop="emit('remove', item.id)"
        >
          <Trash2 :size="14" />
        </button>
      </div>
    </div>
  </section>
</template>

<style scoped>
.queue-panel {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
  background: var(--color-card);
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow-sm);
  padding: 1rem;
  min-width: 0;
}

.queue-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.5rem;
  flex-wrap: nowrap;
  min-height: 2rem;
}

.queue-header-left {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  min-width: 0;
  flex: 1;
}

.queue-select-all {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  cursor: pointer;
  min-width: 0;
}

.queue-select-all input {
  accent-color: var(--color-primary);
  cursor: pointer;
}

.queue-select-all input:disabled {
  cursor: not-allowed;
  opacity: 0.4;
}

.queue-select-all:has(input:disabled) {
  cursor: not-allowed;
}

.queue-title {
  font-size: 0.875rem;
  font-weight: 600;
  color: var(--color-dark);
}

.queue-selected {
  font-size: 0.75rem;
  font-weight: 500;
  color: var(--color-primary);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.queue-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  padding: 2rem 0.5rem;
  color: var(--color-gray-dark);
}

.queue-empty svg {
  opacity: 0.3;
}

.queue-empty p {
  font-size: 0.8125rem;
  font-weight: 500;
  text-align: center;
}

.queue-list {
  display: flex;
  flex-direction: column;
  gap: 0.375rem;
  overflow-y: auto;
  flex: 1;
  min-height: 0;
}

.queue-item {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem;
  border-radius: var(--radius-md);
  border: 1px solid transparent;
  transition:
    background 0.15s ease,
    border-color 0.15s ease;
}

.queue-item:hover {
  background: var(--color-gray);
}

.queue-item.active {
  border-color: var(--color-primary);
  background: rgba(212, 132, 62, 0.06);
}

.queue-item.error {
  background: rgba(220, 38, 38, 0.04);
}

.queue-check-box {
  display: inline-flex;
  flex-shrink: 0;
  cursor: pointer;
}

.queue-check {
  accent-color: var(--color-primary);
  pointer-events: none;
}

.queue-check:disabled {
  opacity: 0.4;
}

.queue-check-box:has(.queue-check:disabled) {
  cursor: not-allowed;
}

.queue-thumb {
  width: 40px;
  height: 40px;
  border-radius: var(--radius-sm);
  object-fit: cover;
  flex-shrink: 0;
  background: var(--color-gray);
}

.queue-item.done,
.queue-item.done .queue-thumb {
  cursor: pointer;
}

.queue-info {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 0.125rem;
}

.queue-name {
  font-size: 0.75rem;
  font-weight: 500;
  color: var(--color-dark);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.queue-meta {
  font-size: 0.6875rem;
  color: var(--color-gray-dark);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}

.queue-item.error .queue-meta {
  color: #dc2626;
}

@property --p {
  syntax: '<number>';
  inherits: true;
  initial-value: 0;
}

.queue-ring {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 30px;
  height: 30px;
  flex-shrink: 0;
  transition: --p 0.2s linear;
}

.queue-ring::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: 50%;
  background: conic-gradient(var(--color-primary) calc(var(--p, 0) * 1%), var(--color-border) 0);
  -webkit-mask: radial-gradient(farthest-side, transparent calc(100% - 3px), #000 0);
  mask: radial-gradient(farthest-side, transparent calc(100% - 3px), #000 0);
}

.queue-ring-label {
  position: relative;
  font-size: 0.5rem;
  font-weight: 600;
  color: var(--color-gray-dark);
  font-variant-numeric: tabular-nums;
  line-height: 1;
}

.queue-done-icon {
  color: #16a34a;
  flex-shrink: 0;
}

.queue-error-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #dc2626;
  flex-shrink: 0;
}

.queue-actions {
  display: flex;
  gap: 0.25rem;
  flex-shrink: 0;
}

.queue-action {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 26px;
  height: 26px;
  padding: 0;
  line-height: 1;
  border-radius: var(--radius-sm);
  background: var(--color-gray);
  color: var(--color-gray-dark);
}

.queue-action:hover {
  background: var(--color-primary);
  color: #fff;
}

.queue-action.copied,
.queue-action.copied:hover {
  background: var(--color-gray);
  color: #16a34a;
}

.queue-cancel {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 26px;
  height: 26px;
  padding: 0;
  line-height: 1;
  border-radius: var(--radius-sm);
  background: var(--color-gray);
  color: var(--color-gray-dark);
  flex-shrink: 0;
  transition:
    background 0.15s ease,
    color 0.15s ease;
}

.queue-cancel:hover {
  background: #dc2626;
  color: #fff;
}

.queue-remove {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 26px;
  height: 26px;
  padding: 0;
  line-height: 1;
  border-radius: var(--radius-sm);
  background: var(--color-gray);
  color: var(--color-gray-dark);
  flex-shrink: 0;
  transition:
    background 0.15s ease,
    color 0.15s ease;
}

.queue-remove:hover {
  background: #dc2626;
  color: #fff;
}

.queue-batch {
  display: flex;
  gap: 0.375rem;
  margin-left: auto;
  flex-wrap: nowrap;
  flex-shrink: 0;
}

.batch-btn {
  display: flex;
  align-items: center;
  gap: 0.3rem;
  padding: 0.375rem 0.5rem;
  font-size: 0.6875rem;
  font-weight: 600;
  background: var(--color-gray);
  color: var(--color-dark);
  border-radius: var(--radius-md);
  white-space: nowrap;
}

.batch-btn:hover:not(:disabled) {
  background: var(--color-primary);
  color: #fff;
}

.batch-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.batch-btn.copied,
.batch-btn.copied:hover {
  background: var(--color-gray);
  color: #16a34a;
}
</style>
