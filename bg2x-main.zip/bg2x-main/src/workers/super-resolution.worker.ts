/// <reference lib="webworker" />

import * as ort from 'onnxruntime-web';
import type { ModelLoadStage, WorkerMessage } from '../type';

// numThreads > 1 deadlocks InferenceSession.create() forever under Electron's
// app:// (Emscripten pthread pool race, microsoft/onnxruntime#26858): A/B tested
// 8 threads => stuck, 1 thread => loads. Browsers keep full multithreading.
const isElectron = typeof navigator !== 'undefined' && navigator.userAgent.includes('Electron');
ort.env.wasm.numThreads = isElectron ? 1 : navigator.hardwareConcurrency || 4;
// Fail wasm backend init instead of hanging forever (0 = no timeout).
ort.env.wasm.initTimeout = 30_000;
console.log(
  `[worker] init numThreads=${ort.env.wasm.numThreads} electron=${isElectron} isolated=${typeof self !== 'undefined' && self.crossOriginIsolated}`,
);

// ── Tiling ────────────────────────────────────────────────────────────────────
// The whole image used to go through a single tensor, which blows past the
// wasm32 int32 tensor limits (SafeIntOnOverflow in safeint.h) for anything
// bigger than ~0.5MP and pins the GPU with a huge allocation. We now run the
// network over overlapping tiles and blend them back, so each inference stays
// small and safe regardless of input size. TILE_SIZE is a multiple of 64 (the
// granularity Swin2SR needs) so tiles stay aligned; the overlap is feathered so
// the seams are invisible.
const TILE_SIZE = 256;
// 16px of source overlap is enough for the feathered blend to hide seams while
// roughly halving the re-computed border pixels versus a 32px overlap
// ((256/240)² ≈ 1.14 vs (256/224)² ≈ 1.31 → ~13% fewer pixels overall).
const TILE_OVERLAP = 16;
const TILE_STEP = TILE_SIZE - TILE_OVERLAP;

// Rebuild the session on CPU if a single tile's inference does not settle in
// this window — guards against a dead GPU kernel / lost device that would
// otherwise leave the promise pending forever.
const INFER_TIMEOUT_MS = 300_000;

// The stitched native output is one RGBA buffer plus a canvas. Beyond these
// bounds browsers either refuse the canvas or OOM, so fail with a clear message
// instead of a cryptic runtime crash.
const MAX_OUTPUT_DIMENSION = 16_384;
const MAX_OUTPUT_PIXELS = 200_000_000;

class AbortError extends Error {
  constructor() {
    super('Processing aborted');
    this.name = 'AbortError';
  }
}

let session: ort.InferenceSession | null = null;
let currentModelId: string | null = null;
let currentGpu = false;
/** Source used to build the current session; kept so we can rebuild it on CPU if GPU inference fails. */
let currentSource: string | ArrayBuffer | null = null;

/** Set by an `abort` message; checked between tiles so cancellation is prompt. */
let abortRequested = false;

/**
 * Messages arrive as macrotasks, so an `abort` queued while a tile run blocks
 * this thread is only dispatched after that run returns — yielding once per tile
 * lets it land before the next tile starts instead of a tile later.
 */
function yieldToEventLoop(): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, 0));
}

/** Id of the job in flight, echoed in every reply so stale results can be dropped. */
let currentJobId: number | null = null;

/** Serialises inference so a replacement job never runs while the cancelled one unwinds. */
let jobChain: Promise<void> = Promise.resolve();

self.onmessage = async (e: MessageEvent<WorkerMessage>) => {
  const message = e.data;

  switch (message.type) {
    case 'load-model':
      await loadModel(
        message.payload.modelId,
        message.payload.modelData,
        message.payload.gpu ?? false,
        message.payload.numThreads,
      );
      break;
    case 'process': {
      const payload = message.payload;
      jobChain = jobChain.then(() => processImage(payload));
      await jobChain;
      break;
    }
    case 'abort':
      abortRequested = true;
      break;
  }
};

function postProgress(
  progress: number,
  status: string,
  tile?: { done: number; total: number },
  stage?: ModelLoadStage,
) {
  self.postMessage({
    type: 'progress',
    payload: { progress, status, jobId: currentJobId, tile, stage },
  });
}

async function createSession(source: string | ArrayBuffer, gpu: boolean) {
  const executionProviders = gpu ? ['webgpu'] : ['wasm'];

  if (typeof source === 'string') {
    return ort.InferenceSession.create(source, {
      executionProviders,
      graphOptimizationLevel: 'all',
    });
  }
  return ort.InferenceSession.create(new Uint8Array(source), {
    executionProviders,
    graphOptimizationLevel: 'all',
  });
}

async function loadModel(
  modelId: string,
  modelData: ArrayBuffer,
  gpu = false,
  numThreads?: number,
) {
  try {
    if (session && currentModelId === modelId && currentGpu === gpu) {
      self.postMessage({ type: 'model-loaded', payload: { modelId, gpu } });
      return;
    }

    // Each worker in the pool gets its slice of the CPU so N concurrent
    // workers do not each grab every core and oversubscribe the machine.
    if (numThreads != null && !isElectron) {
      ort.env.wasm.numThreads = Math.max(1, Math.floor(numThreads));
    }

    postProgress(0, 'Loading model...', undefined, 'session');

    const source = modelData;
    let effectiveGpu = gpu;
    const t0 = performance.now();
    console.log(
      `[worker] createSession start gpu=${gpu} bytes=${source instanceof ArrayBuffer ? source.byteLength : 'url'}`,
    );

    try {
      session = await createSession(source, gpu);
    } catch (gpuError) {
      console.warn(`[worker] gpu session failed (${(performance.now() - t0) | 0}ms): ${gpuError}`);
      if (!gpu) throw gpuError;
      postProgress(0, 'Loading model...', undefined, 'fallback');
      session = await createSession(source, false);
      effectiveGpu = false;
    }

    currentSource = source;
    currentModelId = modelId;
    currentGpu = effectiveGpu;

    console.log(
      `[worker] model loaded in ${(performance.now() - t0).toFixed(0)}ms gpu=${effectiveGpu}`,
    );
    self.postMessage({
      type: 'model-loaded',
      payload: { modelId, gpu: effectiveGpu },
    });
  } catch (error) {
    console.error(`[worker] model load failed: ${error}`);
    self.postMessage({
      type: 'error',
      payload: { message: `Failed to load model: ${error}` },
    });
  }
}

function assertOutputSize(w: number, h: number) {
  if (w > MAX_OUTPUT_DIMENSION || h > MAX_OUTPUT_DIMENSION || w * h > MAX_OUTPUT_PIXELS) {
    throw new Error(
      `Image too large: output would be ${w}×${h}px, exceeding the ` +
        `${MAX_OUTPUT_DIMENSION}px / ${Math.round(MAX_OUTPUT_PIXELS / 1_000_000)}MP limit`,
    );
  }
}

async function processImage(payload: {
  jobId: number;
  imageData: ImageData;
  alpha?: Uint8ClampedArray;
  width: number;
  height: number;
  scale: number;
  targetScale?: number;
}) {
  const { imageData, width, height, scale } = payload;
  const targetScale = payload.targetScale ?? scale;
  // Tracks the run in flight so an early exit (abort or a throwing tile) can
  // neutralise its rejection instead of leaving an unhandled promise behind.
  let pending: Promise<Float32Array> | undefined;

  try {
    if (!session) {
      throw new Error('Model not loaded');
    }

    currentJobId = payload.jobId;
    abortRequested = false;

    // When the requested output is smaller than the model's native scale, shrink
    // each tile right after inference and blend in that smaller space instead of
    // stitching a full native-size image and resampling it at the very end. The
    // stitched buffer shrinks by (scale / targetScale)² — e.g. 4× for 4x→2x.
    const rawFactor = scale / targetScale;
    const downsample = targetScale < scale && Number.isInteger(rawFactor);
    const blendScale = downsample ? targetScale : scale;
    const blendW = width * blendScale;
    const blendH = height * blendScale;
    const outW = width * targetScale;
    const outH = height * targetScale;
    assertOutputSize(blendW, blendH);
    if (outW !== blendW || outH !== blendH) assertOutputSize(outW, outH);

    postProgress(5, 'Preprocessing...');

    const outData = new Uint8ClampedArray(blendW * blendH * 4);
    const alphaPlane = payload.alpha
      ? scaleAlpha(payload.alpha, width, height, blendW, blendH)
      : null;

    const inputName = session.inputNames[0];
    const outputName = session.outputNames[0];

    const tilesX = Math.max(1, Math.ceil((width - TILE_OVERLAP) / TILE_STEP));
    const tilesY = Math.max(1, Math.ceil((height - TILE_OVERLAP) / TILE_STEP));

    // Row-major tile order. The feathered blend is order-dependent (earlier tiles
    // carry full weight, later ones ramp in), so this list is the single source of
    // ordering for both inference and blending.
    const tiles: Array<{ x0: number; y0: number; tx: number; ty: number }> = [];
    for (let ty = 0; ty < tilesY; ty++) {
      for (let tx = 0; tx < tilesX; tx++) {
        tiles.push({ x0: tx * TILE_STEP, y0: ty * TILE_STEP, tx, ty });
      }
    }
    const totalTiles = tiles.length;

    // Two input buffers: the pixel packing for the next tile runs while the GPU is
    // still busy with the current one, instead of the CPU idling between runs.
    // onnxruntime-web forbids concurrent run() on a single session (the run stack
    // is not re-entrant), so exactly one run is ever in flight.
    const buffers = [
      new Float32Array(3 * TILE_SIZE * TILE_SIZE),
      new Float32Array(3 * TILE_SIZE * TILE_SIZE),
    ];
    // Per-axis blend weights: tile 0 is full-weight, later tiles ramp in. Built
    // once per job and shared by every tile instead of reallocated per tile.
    const weights = buildBlendWeights(blendScale);

    let done = 0;
    let inferMs = 0;
    let cpuMs = 0;

    /** Queue tile `index`, optionally reusing a buffer already packed by the caller. */
    const startTile = (index: number, alreadyPacked = false): Promise<Float32Array> => {
      const buffer = buffers[index % 2];
      const { x0, y0 } = tiles[index];
      const refill = () => extractTile(imageData, x0, y0, buffer);
      if (!alreadyPacked) refill();
      const tensor = new ort.Tensor('float32', buffer, [1, 3, TILE_SIZE, TILE_SIZE]);
      return runWithFallback(inputName, outputName, tensor, refill, (ms) => {
        inferMs += ms;
      });
    };

    const jobStart = performance.now();
    pending = startTile(0);

    for (let i = 0; i < totalTiles; i++) {
      const { x0, y0, tx, ty } = tiles[i];

      postProgress(
        10 + Math.round((done / totalTiles) * 70),
        `Running inference... (${done + 1}/${totalTiles})`,
        { done, total: totalTiles },
      );

      const packStart = performance.now();
      if (i + 1 < totalTiles) {
        // Packed one run ahead so this CPU work hides behind the in-flight GPU pass.
        extractTile(imageData, tiles[i + 1].x0, tiles[i + 1].y0, buffers[(i + 1) % 2]);
      }
      cpuMs += performance.now() - packStart;

      const tileOut = await pending;
      if (abortRequested) throw new AbortError();

      const blendStart = performance.now();
      const tileData = downsample ? downsampleTile(tileOut, TILE_SIZE * scale, rawFactor) : tileOut;
      const ax = tx === 0 ? weights.full : weights.ramp;
      const ay = ty === 0 ? weights.full : weights.ramp;
      blendTile(outData, tileData, x0, y0, blendW, blendH, blendScale, ax, ay, alphaPlane);
      cpuMs += performance.now() - blendStart;

      done++;

      if (i + 1 < totalTiles) {
        await yieldToEventLoop();
        if (abortRequested) throw new AbortError();
        pending = startTile(i + 1, true);
      }
    }

    console.log(
      `[worker] tiles=${totalTiles} ep=${currentGpu ? 'webgpu' : 'wasm'} ` +
        `inference=${inferMs | 0}ms cpu=${cpuMs | 0}ms wall=${(performance.now() - jobStart) | 0}ms`,
    );

    if (abortRequested) throw new AbortError();

    postProgress(85, 'Postprocessing...');

    const stitchedImageData = new ImageData(outData, blendW, blendH);
    let resultCanvas: OffscreenCanvas | HTMLCanvasElement = new OffscreenCanvas(blendW, blendH);
    resultCanvas.getContext('2d')!.putImageData(stitchedImageData, 0, 0);

    if (outW !== blendW || outH !== blendH) {
      const scaledCanvas = new OffscreenCanvas(outW, outH);
      const scaledCtx = scaledCanvas.getContext('2d')!;
      scaledCtx.imageSmoothingEnabled = true;
      scaledCtx.imageSmoothingQuality = 'high';
      scaledCtx.drawImage(resultCanvas, 0, 0, outW, outH);
      resultCanvas = scaledCanvas;
    }

    postProgress(92, 'Creating result...');

    const blob = await resultCanvas.convertToBlob({ type: 'image/png' });
    const resultUrl = URL.createObjectURL(blob);

    self.postMessage({
      type: 'complete',
      payload: {
        resultUrl,
        size: { width: outW, height: outH },
        jobId: currentJobId,
      },
    });
  } catch (error) {
    pending?.catch(() => undefined);
    if (error instanceof AbortError) {
      self.postMessage({
        type: 'aborted',
        payload: { message: 'Processing cancelled', jobId: currentJobId },
      });
    } else {
      self.postMessage({
        type: 'error',
        payload: { message: `Processing failed: ${error}`, jobId: currentJobId },
      });
    }
  } finally {
    abortRequested = false;
  }
}

/** Reject if `promise` does not settle within `ms` (used to fence dead GPU runs). */
function withTimeout<T>(promise: Promise<T>, ms: number, label: string): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(() => {
      reject(new Error(`${label} timed out after ${Math.round(ms / 1000)}s`));
    }, ms);
    promise.then(
      (value) => {
        clearTimeout(timer);
        resolve(value);
      },
      (error) => {
        clearTimeout(timer);
        reject(error);
      },
    );
  });
}

/**
 * Run one tile. If the active session is on GPU and the run throws or fails to
 * settle (lost device / stuck kernel), rebuild the session on WASM and retry the
 * same tile once before surfacing a hard error.
 */
async function runWithFallback(
  inputName: string,
  outputName: string,
  tensor: ort.Tensor,
  refill: () => void,
  onRun?: (ms: number) => void,
): Promise<Float32Array> {
  try {
    const results = await timedRun(inputName, tensor, onRun);
    return results[outputName].data as Float32Array;
  } catch (error) {
    if (abortRequested) throw new AbortError();
    if (!currentGpu || !currentSource) throw error;

    self.postMessage({
      type: 'gpu-fallback',
      payload: { message: `GPU inference failed, falling back to CPU: ${error}` },
    });
    postProgress(10, 'GPU failed, retrying on CPU...');

    session = await createSession(currentSource, false);
    currentGpu = false;

    // The aborted GPU run may have partially written to the shared buffer.
    refill();
    const retry = await timedRun(inputName, tensor, onRun);
    return retry[outputName].data as Float32Array;
  }
}

async function timedRun(inputName: string, tensor: ort.Tensor, onRun?: (ms: number) => void) {
  const start = performance.now();
  try {
    return await withTimeout(session!.run({ [inputName]: tensor }), INFER_TIMEOUT_MS, 'Inference');
  } finally {
    onRun?.(performance.now() - start);
  }
}

/** Copy the TILE_SIZE×TILE_SIZE window at (x0, y0) into `out`, replicating edge pixels. */
function extractTile(imageData: ImageData, x0: number, y0: number, out: Float32Array) {
  const { data, width, height } = imageData;
  const plane = TILE_SIZE * TILE_SIZE;
  const inv = 1 / 255;

  // Interior tiles never read outside the image, so skip the per-pixel clamp.
  if (x0 + TILE_SIZE <= width && y0 + TILE_SIZE <= height) {
    for (let ly = 0; ly < TILE_SIZE; ly++) {
      let si = ((y0 + ly) * width + x0) * 4;
      let di = ly * TILE_SIZE;
      const diEnd = di + TILE_SIZE;
      for (; di < diEnd; di++, si += 4) {
        out[di] = data[si] * inv;
        out[plane + di] = data[si + 1] * inv;
        out[2 * plane + di] = data[si + 2] * inv;
      }
    }
    return;
  }

  for (let ly = 0; ly < TILE_SIZE; ly++) {
    const sy = Math.min(height - 1, Math.max(0, y0 + ly));
    const rowBase = sy * width;
    const outRow = ly * TILE_SIZE;
    for (let lx = 0; lx < TILE_SIZE; lx++) {
      const sx = Math.min(width - 1, Math.max(0, x0 + lx));
      const si = (rowBase + sx) * 4;
      const di = outRow + lx;
      out[di] = data[si] * inv;
      out[plane + di] = data[si + 1] * inv;
      out[2 * plane + di] = data[si + 2] * inv;
    }
  }
}

/**
 * Precompute the per-axis blend weights once per job. Only two profiles exist:
 * the first tile on an axis contributes fully (`full`), every later tile ramps
 * linearly across the overlap (`ramp`). Both axes share the same profile.
 */
function buildBlendWeights(blendScale: number) {
  const ow = TILE_SIZE * blendScale;
  const overlap = TILE_OVERLAP * blendScale;
  const full = new Float32Array(ow).fill(1);
  const ramp = new Float32Array(ow);
  for (let o = 0; o < ow; o++) {
    ramp[o] = Math.min(1, o / overlap);
  }
  return { full, ramp };
}

/** Box-filter one tile's RGB planes from (ow×ow) down to (ow/factor)². */
function downsampleTile(src: Float32Array, ow: number, factor: number): Float32Array {
  const owT = ow / factor;
  const planeSrc = ow * ow;
  const planeDst = owT * owT;
  const dst = new Float32Array(3 * planeDst);
  const inv = 1 / (factor * factor);

  for (let y = 0; y < owT; y++) {
    const sy0 = y * factor;
    for (let x = 0; x < owT; x++) {
      const sx0 = x * factor;
      let r = 0;
      let g = 0;
      let b = 0;
      for (let dy = 0; dy < factor; dy++) {
        let si = (sy0 + dy) * ow + sx0;
        for (let dx = 0; dx < factor; dx++, si++) {
          r += src[si];
          g += src[planeSrc + si];
          b += src[2 * planeSrc + si];
        }
      }
      const di = y * owT + x;
      dst[di] = r * inv;
      dst[planeDst + di] = g * inv;
      dst[2 * planeDst + di] = b * inv;
    }
  }
  return dst;
}

/**
 * Resample the source alpha onto the blend buffer's pixel grid. The mask is
 * painted over white and read back from the alpha channel so the browser
 * interpolates it in premultiplied space; a grayscale RGB image would drag black
 * into every reduced-alpha pixel instead.
 */
function scaleAlpha(
  alpha: Uint8ClampedArray,
  srcW: number,
  srcH: number,
  dstW: number,
  dstH: number,
): Uint8ClampedArray {
  if (srcW === dstW && srcH === dstH) return alpha;

  const source = new ImageData(srcW, srcH);
  for (let i = 0, p = 0; i < alpha.length; i++, p += 4) {
    source.data[p] = 255;
    source.data[p + 1] = 255;
    source.data[p + 2] = 255;
    source.data[p + 3] = alpha[i];
  }

  const srcCanvas = new OffscreenCanvas(srcW, srcH);
  srcCanvas.getContext('2d')!.putImageData(source, 0, 0);
  const dstCanvas = new OffscreenCanvas(dstW, dstH);
  const ctx = dstCanvas.getContext('2d')!;
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(srcCanvas, 0, 0, dstW, dstH);

  const scaled = ctx.getImageData(0, 0, dstW, dstH).data;
  const out = new Uint8ClampedArray(dstW * dstH);
  for (let i = 0, p = 3; i < out.length; i++, p += 4) out[i] = scaled[p];
  return out;
}

/**
 * Blend a tile's network output into the final buffer. Where tiles overlap the
 * contribution is feathered back in (linear ramp across TILE_OVERLAP), the first
 * tile along each axis always contributing fully. `ax`/`ay` are the precomputed
 * per-axis weights; `blendScale` maps source pixels to the destination buffer,
 * which is the native scale unless the output was downsampled first. `alphaPlane`
 * carries the source alpha resampled into the same destination space; without it
 * every pixel is written fully opaque.
 */
function blendTile(
  out: Uint8ClampedArray,
  tile: Float32Array,
  x0: number,
  y0: number,
  destW: number,
  destH: number,
  blendScale: number,
  ax: Float32Array,
  ay: Float32Array,
  alphaPlane: Uint8ClampedArray | null,
) {
  const ow = TILE_SIZE * blendScale;
  const plane = ow * ow;
  const baseX = x0 * blendScale;
  const baseY = y0 * blendScale;

  for (let oy = 0; oy < ow; oy++) {
    const gy = baseY + oy;
    if (gy >= destH) break;
    const aY = ay[oy];
    const tileRow = oy * ow;
    for (let ox = 0; ox < ow; ox++) {
      const gx = baseX + ox;
      if (gx >= destW) break;

      const ti = tileRow + ox;
      const r = tile[ti] * 255;
      const g = tile[plane + ti] * 255;
      const b = tile[2 * plane + ti] * 255;
      const di = (gy * destW + gx) * 4;

      const a = aY * ax[ox];
      if (a >= 1) {
        out[di] = r;
        out[di + 1] = g;
        out[di + 2] = b;
      } else {
        const inv = 1 - a;
        out[di] = out[di] * inv + r * a;
        out[di + 1] = out[di + 1] * inv + g * a;
        out[di + 2] = out[di + 2] * inv + b * a;
      }
      out[di + 3] = alphaPlane ? alphaPlane[gy * destW + gx] : 255;
    }
  }
}
